// event handlers // обработчики событий
// event listeners // прослушиватели событий
const { head, startBody, scripts, endBody } = require('./consts');
const fs = require('fs/promises');

const parseFile = data => {
    return data.split('\n').map(row => {
        const arrRows = row.replace('\r', '').split('\t');
        arrRows.length = 6; // count columns
        return arrRows;
    });
}

const createHtmlFile = dataArray => {
    const s = (className, text) => `<span class="${className}">${text}</span>`;
    const sColor = color => `<span class="color ${color ? `${color}_mod` : ''}"></span>`;

    let list = '';
    dataArray.forEach(arr => {
        const [numKey, color, codeDuplicate, address, name, descriptions] = arr;
        list += `\t\t<li class="object_item js-item">
            ${sColor(color)}
            ${numKey        ? s('num_key', numKey) : ''}
            ${codeDuplicate ? s('code', `(код ${codeDuplicate})`) : ''}
            ${address       ? s('address', address) : ''}
            ${name          ? s('name', name) : ''}
            ${descriptions  ? s('descriptions', `(${descriptions})`) : ''}\r\t\t</li>\r`
            .replace(/>\s+</g, '>\r\t\t\t<')
            .replace(/\t\t\t<\/li>/g, '\t\t</li>')
            .replace(/\t\t\t<li/g, '\t\t<li');
    });

    return `${head}${startBody}${list}${scripts}${endBody}`;
}

async function example() {
    // const absFileName = 'd:/albor/web_js_lessons/tasks/ask_data.txt';
    const srcFileName = './data_files/key_data.tsv';
    const distFileName = './index.html';
    try {
        const data = await fs.readFile(srcFileName, 'utf8');
        // console.log(data);
        const arrayStrings = parseFile(data);
        const content = createHtmlFile(arrayStrings);
        // console.log(content);
        await fs.writeFile(distFileName, content);
        // console.log('Wrote some content!');
        // const newData = await fs.readFile(fileName, 'utf8');
        // console.log(newData);
    } catch (err) {
        console.log(err);
    } finally {

    }
}
example();






